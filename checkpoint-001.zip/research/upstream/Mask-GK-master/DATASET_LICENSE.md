# GBISC Dataset License

The GBISC dataset (images and annotations) is released under the
Creative Commons Attribution 4.0 International License (CC BY 4.0),
which permits use, sharing, adaptation, distribution and reproduction
in any medium or format, as long as you give appropriate credit to the
original author(s) and the source, provide a link to the Creative
Commons license, and indicate if changes were made.

To view a copy of this license, visit
http://creativecommons.org/licenses/by/4.0/

If you use this dataset in your research, please cite:

```bibtex
@article{yang2025mask,
  title={Mask-GK: An efficient method based on mask Gaussian kernel for segmentation and counting of grape berries in field},
  author={Yang, Canchen and Geng, Tianyu and Peng, Jian and Xu, Chun and Song, Zichen},
  journal={Computers and Electronics in Agriculture},
  volume={234},
  pages={110286},
  year={2025},
  publisher={Elsevier}
}
```